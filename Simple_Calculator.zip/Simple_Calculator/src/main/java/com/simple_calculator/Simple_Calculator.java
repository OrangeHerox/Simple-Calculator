package com.simple_calculator;

public class Simple_Calculator {

    public static void main(String[] args) {
        settingMain sm = new settingMain();
        sm.setMainGui();
        sm.setOutput();
        sm.setButtons();
        sm.buttonAction();
    }
}
